package com.example.market.auth.dto;

import lombok.Data;

@Data
public class RequestUpgradeDto {
    private String registrationNum;
}
