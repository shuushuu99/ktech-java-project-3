package com.example.market.auth.dto;

import lombok.Data;

@Data
public class JwtResponseDto {
    private String token;
}
