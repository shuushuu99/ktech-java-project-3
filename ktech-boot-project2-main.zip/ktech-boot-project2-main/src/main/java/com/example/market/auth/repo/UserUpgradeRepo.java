package com.example.market.auth.repo;

import com.example.market.auth.entity.UserUpgrade;
import org.springframework.data.jpa.repository.JpaRepository;

public interface UserUpgradeRepo extends JpaRepository<UserUpgrade, Long> {}
